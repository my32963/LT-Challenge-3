/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void findLongestSubarray(int arr[],int n,int k)
{
    int start = 0, end= 0;
    int current_sum = arr[0],
    max_length = 0;
    for(int i=1; i<n;i++)
    {
        if(current_sum /(i-start +1) >= k)
        {
            if(i - start + 1> max_length)
            {
                max_length= i - start + 1;
                end = i;
            }
        }
        else
        {
            start = i;
            current_Sum = arr[i];
        }
    }
    printf("Longest subarray with average greater than or equal to %d is from index %d to %d\n",k,end-max_length + 1, end);
}


int main(){
    int n,k;
    
    printf("Enter the size of the array:");
    scanf("%d",&n);
    
    int arr[n];
    
    printf("Enter the element of the array:\n");
    for (int i=0; i<n; i++){
        scanf("%d", &arr[i]);
    }
    printf("Enter the value of k:");
    scanf("%d", &k);findLongestSubarray(arr, n, k);
    
    return 0;
}
