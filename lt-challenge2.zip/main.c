/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <driver/gpio.h>

#define LED_PIN GPIO_NUM_2  //Define GPIO pin for LED_PIN

void temperature Task(void
*pvParameters);
void ledBlinkTask(void
*pvParameters);

// semaphore to signal the led

SemaphoreHandle_t
temperatureUpdatedSemaphore;

// variable to store CPU temperatureUpdatedSemaphore

float cpu Temperature = 0.0;

void setup(){
    temperatureUpdatedSemaphore = 
    xSemaphoreCreateBinary();
    
    //initialize GPIO for led 
    
    gpio_config_t io_conf = {
        .pin_bit_mask=
        (1 ULL << LED_PIN),
        .mode = GPIO_MODE_OUTPUT<
        .intr_type = GPIO_INTR_DISABLE,
        .pull_up_en =
        GPIO_PULLUP_DISABLE,
        .pull_down_en =
        GPIO_PULLUP_DISABLE,
        .gpio_mask = 0
    };
    gpio_confog(&io_conf);
    
    
    // create Task
    
    xTaskCreater(temperature Task,"TemperatureTask",2048,NULL, 2, NULL);
    
}

void loop(){
    // nothing to be done here
}

void temperatureTask(void
*pvParameters){
    while(1){
        cpuTemperature = 30.0 + rand() % 10;
        
        // Notify the LED task 
        
        xSemaphoreGiven(temperatureUpdatedSemaphore);
        vTaskDelay(pdMS_TO_TICKS(100))
    }
}

void ledBlinkTask(void*pvParameters){
    while(1){
        if(xSemaphoreTake(temperatureUpdatedSemaphore, portMAX_DELAY)){
            gpio_se_level(LED_PIN,1);
            
            vTaskDelay(pdMS_TO_TICKS(100));
            gpio_se_level(LED_PIN,0);
        }
    }
}


